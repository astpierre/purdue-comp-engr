public interface FlyBehavior {
    public void fly();
}