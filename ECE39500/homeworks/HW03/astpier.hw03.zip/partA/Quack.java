public class Quack {
}
