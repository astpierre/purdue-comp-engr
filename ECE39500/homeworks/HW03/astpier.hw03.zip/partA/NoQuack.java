public class NoQuack implements QuackBehavior {
    public void quack() {
        System.out.println("<< NoQuack :( >>");
    }
}