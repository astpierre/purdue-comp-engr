class Move
  def move
    puts "<<move>>"
  end
end
