## partB for hw03

### Running
`ruby simulator.rb`
