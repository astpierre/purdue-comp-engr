require_relative 'talk'

class Mute < Talk
    def talk
        puts "mute..."
    end
end
