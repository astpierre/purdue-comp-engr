require_relative 'move'

class Swim < Move
    def move
        puts "swimming"
    end
end