require_relative 'talk'

class Meow < Talk
    def talk
        puts "Meow... meowww...."
    end
end