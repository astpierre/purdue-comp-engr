class Talk
  def talk
    puts "<<talk>>"
  end
end
