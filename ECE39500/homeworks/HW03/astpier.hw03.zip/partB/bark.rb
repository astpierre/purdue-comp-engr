require_relative 'talk'

class Bark < Talk
    def talk
        puts "BARK! BARK! BARK!"
    end
end