require_relative 'move'

class Walk < Move
    def move
        puts "walking"
    end
end