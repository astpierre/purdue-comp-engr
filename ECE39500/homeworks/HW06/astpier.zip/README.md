# ECE395: HW06  
### Testing  
to run (if python3.8 is installed): `$ ./main.py`  
to run (if python version < python3.8 is installed): `$ python3 main.py`
