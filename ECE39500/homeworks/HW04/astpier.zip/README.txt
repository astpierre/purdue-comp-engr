To run simulation
    $ ruby simulation.rb
