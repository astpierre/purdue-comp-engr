To build:
  ant

To run:
  java -jar midterm.jar testpgm.txt
  java -jar midterm.jar testpgm2.txt
