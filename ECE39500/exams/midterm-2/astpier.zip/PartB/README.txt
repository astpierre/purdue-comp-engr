To build:
  ant

To run:
  java -jar midterm.jar testpgm3.txt
