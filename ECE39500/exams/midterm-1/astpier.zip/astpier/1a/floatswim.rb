require_relative 'swimbehavior'

class FloatSwim < SwimBehavior

    def do
        "floating in the pond"
    end
end

