require_relative 'quackbehavior'

class QuackQuack < QuackBehavior

    def do
        super + " QUACK QUACK"
    end

end
