require_relative 'behavior'

class QuackBehavior < Behavior

    def do
        "Quack"
    end

end
