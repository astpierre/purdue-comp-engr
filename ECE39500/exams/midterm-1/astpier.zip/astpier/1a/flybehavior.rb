require_relative 'behavior'

class FlyBehavior < Behavior

    def do
        "Fly"
    end

end
