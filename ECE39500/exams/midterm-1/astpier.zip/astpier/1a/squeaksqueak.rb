require_relative 'quackbehavior'

class SqueakSqueak < QuackBehavior

    def do
        "SQUEAK SQUEAK"
    end

end
