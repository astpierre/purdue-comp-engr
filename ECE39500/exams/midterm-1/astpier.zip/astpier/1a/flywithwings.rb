require_relative 'flybehavior'

class FlyWithWings < FlyBehavior

    def do
        super + " WITH WINGSSSS"
    end

end
