require_relative 'behavior'

class SwimBehavior < Behavior

    def do
        "Swim"
    end

end
