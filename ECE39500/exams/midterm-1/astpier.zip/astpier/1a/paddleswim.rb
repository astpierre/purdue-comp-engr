require_relative 'swimbehavior'

class PaddleSwim < SwimBehavior

    def do
        "paddle in the pond"
    end
end

